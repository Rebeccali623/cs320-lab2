import pandas as pd
from flask import Flask, request, jsonify, Response
import re
import matplotlib
from matplotlib import pyplot as plt
from io import StringIO

matplotlib.use('Agg')

app = Flask(__name__)
df = pd.read_csv("main.csv")

home_visits = 0
donate_links = [
    '<p><a href="donate.html?from=A">donate</a></p>',
    '<p><a href="donate.html?from=B">DONATE</a></p>',
]
from_counts = {"A": 0, "B": 0}

@app.route('/')
def home():
    global home_visits
    with open("index.html") as f:
        html = f.read()

    link = donate_links[home_visits % 2]
    if home_visits >= 10:
        if from_counts["A"] > from_counts["B"]:
            link = donate_links[0]
        else:
            link = donate_links[1]

    home_visits += 1
    return html.replace("DONATE", link)

@app.route('/donate.html')
def donate():
    version = request.args.get("from")
    if version in from_counts:
        from_counts[version] += 1
    return "<h1>Donate</h1>thanks!"

@app.route('/browse.html')
def browse():
    html = """
    <html><body>
    <h1>Browse</h1>
    {}
    </body></html>
    """
    with pd.option_context("display.max_rows", None, "display.max_columns", None):
        return html.format(df._repr_html_())

n = 0
    
@app.route('/email', methods=["POST"])
def email():
    global n
    email = str(request.data, "utf-8")
    if re.match(r"\w+\@\w+\.\w+", email): # 1
        with open("emails.txt", "a") as f: # open file in append mode
            f.write(email + "\n") # 2
        n += 1
        return jsonify("thanks, you're subscriber number {}!".format(n))
    return jsonify("bad, bad, bad!") # 3

@app.route('/max-deaths.svg')
def maxdeath():
    fig, ax = plt.subplots()
    df.set_index("name")["deaths"].sort_values()[-10:].plot.bar(ax=ax)
    ax.set_ylabel("Deaths")
    ax.set_xlabel(f"Top 10 Hurricanes")
    t = StringIO()
    fig.savefig(t, format="svg", bbox_inches="tight")
    plt.close(fig)
    return Response(t.getvalue(), headers={
        "Content-Type": "image/svg+xml",
    })

@app.route('/by-year.svg')
def byyear():
    year = request.args.get("year")
    fig, ax = plt.subplots()
    mph = df[df["formed"].str.endswith(year)].set_index("name")["mph"]
    mph.plot.bar(ax=ax)
    ax.set_ylabel("MPH")
    ax.set_xlabel(f"{year} Hurricanes")
    t = StringIO()
    fig.savefig(t, format="svg", bbox_inches="tight")
    plt.close(fig)
    return Response(t.getvalue(), headers={
        "Content-Type": "image/svg+xml",
    })

if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True) # don't change this line!
